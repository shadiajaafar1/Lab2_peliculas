'''
Análisis descriptivo de los datos

Para la realización de este proyecto se usó el Dataset "IMBD TO 250 MOVIES" disponible en Kaggle. 
Los datos fueron extraídos del sitio web de IMBD (www.imbd.com) y se seleccionaron las mejores 250 películas 
de acuerdo con la calificacióm IMBD, también se recopiló información como el titulo, el elenco, 
el año de lanzamiento, la calificación, entre otros.
Este dataset cuenta con 13 variables entre cualiativas y cuantitativas, ellas son:
rank, name, year, rating, genre, certificate, run_time, tagline, budget, box_office, casts, directors, writers.

Inicimos probando la normalidad de las variables cuantitativas.
El nivel de significancia que se estará usando es de 0.05
Se usará el test de Kolmogorov- Smirnov dado que la muestra es grande (>30)
'''
from scipy.stats import kstest
import numpy as np
import pandas as pd

data = pd.read_csv("datos.csv")

# Realizar el test de normalidad de Kolmogorov-Smirnov 

statistic, p_value = kstest(data['year'], 'norm')
print("Year")
print("El p-valor es ", p_value)
print("La variable year no tiene un distribución aproximadamente normal")

statistic, p_value_1 = kstest(data['rating'], 'norm')
print("Rating")
print("El p-valor es ", p_value_1)
print("La variable year no tiene un distribución aproximadamente normal")

statistic, p_value_2 = kstest(data['budget'], 'norm')
print("Budget")
print("El p-valor es ", p_value_2)
print("La variable budget no tiene un distribución aproximadamente normal")

statistic, p_value_3 = kstest(data['box_office'], 'norm')
print("Box_office")
print("El p-valor es ", p_value_3)
print("La variable box_office no tiene un distribución aproximadamente normal")

# Ninguna de las variables tiene una distribución normal

'''
Ahora, analicemos la correlacion entre las variables cuantitativas. (Ver 'Matriz de correlación de 
Variables Cuantitativas' del Dash Board).
Observamos que la correlación entre las variables cuantitativas es muy baja. Esto representa un inconveniente si
deseamos realizar un modelo de regresión lineal múltiple ya que el modelo explicará un porcentaje muy bajo de la 
variablidad de la variable respuesta y por lo tanto no podrá hacer buenas predicciones. 

Veamos las variables cualitativas:
(Ver diagrama de barras de variables cualitativas)
Podemos observar que en la variable genre (genero de la pelicula), el genero drama es el que presenta la mayor frecuencia 
seguimo de crime, drama.
Por otro lado, en la variable year podemos notar que el año de lanzamiento con mayor frecuencia fue 1995, seguido del 2004
En el caso de la variable casts (reparto de la pelicula), observamos que todos los datos tienen una frecuencia de 1, 
esto quiere decir que son únicos.
Para la variable directors (directores de la pelicula), observamos que los directores con la mayor frecuencia son: Steven Spielberg,
Robert Zerreckis, Martin Scorsee y Stanley Kubrick.
Por último, en la variable writers observamos que el escritor con la mayor frecuencia es Charles Chaplin.

'''
#Escogencia de la técnica que se va a usar

'''
Debido a que los datos proporcionados no cumplían con los supuestos para realizar un modelo de Regresión lineal Múltiple
por la baja correlación entre las variable cuantitativas. Decidimos realizar la técnica 'Clustering' la cual consiste en
agrupar los datos en grupos con características similares (clusters). 
En este caso decidimos usar las siguientes variables: genre, year, casts.
(Vea clustering.py)
'''


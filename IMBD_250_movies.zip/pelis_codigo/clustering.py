import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from scipy.cluster.hierarchy import dendrogram, linkage


class Clustering:
    def __init__(self):
        self.movies = pd.read_csv("datos_pelis.csv", encoding='latin1')
        self.X = self.movies[['genre', 'year', 'casts']]
        # Convertir las variables de texto en variables numéricas para el clustering
        le = LabelEncoder()
        self.X['genre'] = le.fit_transform(self.X['genre'])
        self.X['casts'] = le.fit_transform(self.X['casts'])
        self.X['year'] = le.fit_transform(self.X['year'])
        
    def clustering(self):
        kmeans = KMeans(n_clusters=2, n_init=25, random_state=10)
        kmeans.fit(self.X)
        #Clusters: 3, repeticiones 25, semilla:10
       
        # Visualizar el clustering
        fig = plt.figure(figsize=(10, 10))
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(self.X['genre'], self.X['year'], self.X['casts'], c=kmeans.labels_)
        ax.set_xlabel('genre')
        ax.set_ylabel('year')
        ax.set_zlabel('casts')
        plt.title("Clustering de IMDB Top 250 Movies ")
        plt.show()
        #nuevo dataframe con la info del clustering
        self.movies['cluster'] = kmeans.labels_
        clusters_df = pd.DataFrame(kmeans.labels_, columns=['cluster'])
        clusters_df['name'] = self.movies['name']
        clusters_df['rank'] = self.movies['rank']
        cluster_1_df = clusters_df[clusters_df['cluster'] == 0][['name', 'rank']]
        cluster_2_df = clusters_df[clusters_df['cluster'] == 1][['name', 'rank']]
        ## imprime lista las peliculas segun su cluster
        print("GRUPO 1: ", cluster_1_df)
        print("GRUPO 2: ", cluster_2_df)


    # Método elbow para identificar el número óptimo de clusters
    def elbow(self):
        inertias = []
        range_n_clusters = range(1, 15)
        for n_clusters in range_n_clusters:
            kmeans = KMeans(n_clusters=n_clusters, n_init=20, random_state=123)
            kmeans.fit(self.X)
            inertias.append(kmeans.inertia_)
        #nuevo dataframe con la info del clustering
        fig, ax = plt.subplots(1, 1, figsize=(6, 3.84))
        ax.plot(range_n_clusters, inertias, marker='o')
        ax.set_xlabel('Número clusters')
        ax.set_ylabel('Intra-cluster (inertia)')
        ax.set_title("Evolución de la varianza intra-cluster total")
        plt.show()

    # clustering jerárquico
    def jerarquico(self):
        Z = linkage(self.X, method='ward')
        fig = plt.figure(figsize=(10, 10))
        dn = dendrogram(Z)
        plt.title("Dendrograma de IMDB Top 250 Movies")
        plt.xlabel("indices segun el Rank de las Peliculas")
        plt.ylabel("Distancia")
        plt.show()

if __name__ == '__main__':
    clustering = Clustering()

    #menu de opciones 
    while True:
        print("Por favor, seleccione una opción: ")
        print("1. Clustering de IMDB Top 250 Movies ")
        print("2. Dendrograma de IMDB Top 250 Movies ")
        print("3. Ver Elbow Method (ELECCION DEL NUMERO DE CLUSTERS)")
        print("4. Salir")

        op = input()

        if op == '1':
            clustering.clustering()
        elif op =='2':
            clustering.jerarquico()
        elif op == '3':
            clustering.elbow()
        elif op == '4':
            print("¡Hasta la próxima!")
            break
        else:
            print("Ingrese una opción válida.")

import pandas as pd
import networkx as nx

class Pelicula: 
    def __init__(self, name, directors, genre) -> None:
        
        self.name = name 
        self.directors = directors 
        self.genre = genre
    
    def __str__(self): 

        return f"Name {self.name}\nDirectors: {self.directors}\nGenre: {self.genre}"
    
# lee el archivo CSV en un dataframe de Pandas
df = pd.read_csv('datos.csv', encoding='latin1')

# crea el grafo
G = nx.Graph()

# crea nodos para cada película y agrega atributos
for index, row in df.iterrows():
    pelicula_actual = Pelicula(row["name"], row["directors"], row["genre"])
    G.add_node(pelicula_actual)
    
for node1 in G.nodes():
    for node2 in G.nodes():
        if node1 != node2:
            if isinstance(node1, Pelicula) and isinstance(node2, Pelicula):
                if node1.genre == node2.genre:
                    G.add_edge(node1, node2)
                if node1.directors == node2.directors:
                    G.add_edge(node1, node2)

nodos = list(filter(lambda peli: peli is not None, list(nx.dfs_preorder_nodes(G))))

#genero de interes
genero = "Drama"
peli_filtradas = {"name": [], "genre": [], "directors": []}

for nodo in nodos:
    if nodo.genre in genero: 
        peli_filtradas["name"].append(nodo.name)
        peli_filtradas["genre"].append(nodo.genre)
        peli_filtradas["directors"].append(nodo.directors)



df_peli_filtradas = pd.DataFrame.from_dict(peli_filtradas)

director_1 = "Peter Jackson"
director_2 = "Ridley Scott"

#se calcula la probabilidad de que ambas condiciones (los directores y el género de la película) se cumplan dividiendo el número de películas en común 
# entre peliculas_comunes_genero y el número total de películas en el género de drama en el dataframe df_genero.
peliculas_director_1 = df_peli_filtradas[df_peli_filtradas["directors"].str.contains(director_1)]
peliculas_director_2 = df_peli_filtradas[df_peli_filtradas["directors"].str.contains(director_2)]
peliculas_comunes = pd.merge(peliculas_director_1, peliculas_director_2, on="name")
peliculas_genero = df_peli_filtradas["name"]

# Encuentra las películas en la intersección de las listas de películas
peliculas_comunes_genero = peliculas_comunes[peliculas_comunes["name"].isin(peliculas_genero)]

# Calcula la probabilidad
probabilidad = len(peliculas_comunes_genero) / len(peliculas_genero)

print(f"la probabilidad de que {director_1} y {director_2} trabajen juntos en una pelicula de {genero} es de {probabilidad}")
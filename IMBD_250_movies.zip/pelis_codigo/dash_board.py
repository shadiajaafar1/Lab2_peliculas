# Importar paquetes
from dash import Dash, html, dash_table, dcc
import pandas as pd
import plotly.express as px
import plotly.graph_objs as go
import pandas as pd
from sklearn.cluster import KMeans
import dash_html_components as html
from sklearn.preprocessing import LabelEncoder

# Leer los datos
df = pd.read_csv('datos_pelis.csv')
# Crear otro dataframe con las variables genre, year, casts para realizar el clustering
X = df[['genre', 'year', 'casts']]

# Convertir las variables de texto en variables numéricas para el clustering
le = LabelEncoder()
X['genre'] = le.fit_transform(X['genre'])
X['casts'] = le.fit_transform(X['casts'])
X['year'] = le.fit_transform(X['year'])
 
# Realizar el clustering con k-means
kmeans = KMeans(n_clusters=2, n_init=25, random_state=10)
#---- Clusters: 3, repeticiones 25, semilla:10
kmeans.fit(X)

# Crear una nueva columna en el DataFrame original con las etiquetas de los clusters
df['cluster'] = kmeans.labels_

# Crear un nuevo dataframe con los clusters y el nombre y ranking de las películas
clusters_df = pd.DataFrame(kmeans.labels_, columns=['cluster'])
clusters_df['name'] = df['name']
clusters_df['rank'] = df['rank']

# Filtrar por cada cluster y seleccionar las columnas necesarias
cluster_1_df = clusters_df[clusters_df['cluster'] == 0][['name', 'rank']]
cluster_2_df = clusters_df[clusters_df['cluster'] == 1][['name', 'rank']]

# Crear el scatter plot 3D con el resultado del clustering
fig = go.Figure(data=[go.Scatter3d(
    x=X['genre'],
    y=X['year'],
    z=X['casts'],
    mode='markers',
    marker=dict(
        size=6,
        color=kmeans.labels_, 
        opacity=0.8,
        colorscale='Viridis', 
        colorbar=dict(title='Cluster')  
    )
)])
fig.update_layout(
    width=800,  # anchura del gráfico
    height=800,  # altura del gráfico
    scene=dict(
        xaxis=dict(title='Género'),  # nombre del eje x
        yaxis=dict(title='Reparto'),  # nombre del eje y
        zaxis=dict(title='Año')  # nombre del eje z
    )
)
# Diagrama circular de la variable casts
counts = df['casts'].value_counts()

# Crear la figura del diagrama circular
fig_2 = go.Figure(data=[go.Pie(
    labels=counts.index,
    values=counts.values,
    insidetextorientation='radial',
    hole=0.3,
    textinfo='label',
    marker=dict(colors=['#FFA07A', '#ADD8E6', '#90EE90', '#FA8072', '#B0C4DE'])
)])

# Actualizar el diseño de la figura
fig_2.update_layout(
    height=500,
    width=700,
    legend=dict(
        title='Casts',
        font=dict(size=12),
        yanchor='top',
        y=0.5,
        xanchor='right',
        x=0.95
    )
)
 

# Inicializar la app
app = Dash(__name__)

# App layout
app.layout = html.Div([
    html.H1(children='IMBD TOP 250 MOVIES', style={ #Titulo
        'textAlign': 'center',
        'fontSize': '40px',
        'color': '#9b5de5',
        'fontFamily': 'Arial'
    }),
    html.H1(children='Análisis descriptivo', style={ #Subtitulo
        'fontSize': '25px',
        'color': '#f15bb5',
        'fontFamily': 'Arial'
    }),html.H1(children='Matriz de Correlación de Variables Cuantitativas', style={
        'fontSize': '20px',
        'color': '#f15bb5',
        'fontFamily': 'Arial'
    }),
    dcc.Graph(id='scatter_matrix', # Matriz de Correlación de las variables cuantitativas 
              figure={
                  'data': [
                      go.Splom(
                          dimensions=[dict(label='rating',
                                            values=df['rating']),
                                      dict(label='budget',
                                            values=df['budget']),
                                      dict(label='box_office',
                                            values=df['box_office'])],
                          marker=dict(color=df['rank'],
                                      colorscale='Viridis', size=5, showscale=False)
                      )
                  ],
                  'layout': go.Layout(
                      title='Scatter Matrix',
                      dragmode='select',
                      width=1000,
                      height=800,
                      hovermode='closest'
                  )
              }),
    html.H1(children='Diagramas de Barras Variables Cualitativas', style={ #Subtitulo
        'fontSize': '20px',
        'color': '#f15bb5',
        'fontFamily': 'Arial'
    }),
    #dash_table.DataTable(data=df.to_dict('records'), page_size=10), # Data frame usado
    dcc.Graph(figure=px.bar(df, x='genre', title = 'Frecuencias de la variable genre', color_discrete_sequence = ['#00bbf9'])), # Diagrama de barras de la variable genre
    dcc.Graph(figure=px.bar(df, x='year', y='year', title = 'Frecuencias de la variable year', color_discrete_sequence = ['#00bbf9'])), # Diagrama de barras de la variable year
    dcc.Graph(figure=px.bar(df, x='casts', title = 'Frecuencias de la variable casts', color_discrete_sequence = ['#00bbf9'])),# Diagrama de barras de la variable casts
    dcc.Graph(figure=px.bar(df, x='directors', title = 'Frecuencias de la variable directors',color_discrete_sequence = ['#00bbf9'])),
    dcc.Graph(figure=px.bar(df, x='writers', title = 'Frecuencias de la variable writers', color_discrete_sequence = ['#00bbf9'])),# Diagrama de barras de la variable directors
    
    html.H1(children='Clustering IMBD TOP 250 Movies', style={ # Subtitulo
        'fontSize': '25px',
        'color': '#fee440',
        'fontFamily': 'Arial'
    }),
    dcc.Graph(id='scatter_3d', # Diagrama de dispersión 3D cluster
              figure=fig),
    html.H1(children='Películas que pertenecen al primer cluster', style={
        'fontSize': '20px',
        'color': '#480355',
        'fontFamily': 'Arial'
    }),
    dash_table.DataTable( # Data frame de las peliculas del cluster 1
    data=cluster_1_df.to_dict('records'),
    page_size=10,
    style_table={
        'width': '500px',
        'height': '300px'
    },
    style_cell={
        'textAlign': 'left',
        'whiteSpace': 'normal',
        'height': 'auto',
    }
),
    html.H1(children='Películas que pertenecen al segundo cluster', style={ 
        'fontSize': '20px',
        'color': '#FDE12D',
        'fontFamily': 'Arial'
    }),
    dash_table.DataTable( # Data frame de las peliculas del cluster 1
    data=cluster_2_df.to_dict('records'),
    page_size=10,
    style_table={
        'width': '500px',
        'height': '300px'
    },
    style_cell={
        'textAlign': 'left',
        'whiteSpace': 'normal',
        'height': 'auto',
    }
    )  
])

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)


